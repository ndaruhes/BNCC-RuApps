module.exports = {
    same: 'harus sama dengan :same',
    email: 'harus yang valid',
    min: {
        'numeric': 'minimal :min',
        'string':  'minimal :min huruf'
    },
    numeric: 'harus berupa angka',
    required: 'wajib diisi'
}