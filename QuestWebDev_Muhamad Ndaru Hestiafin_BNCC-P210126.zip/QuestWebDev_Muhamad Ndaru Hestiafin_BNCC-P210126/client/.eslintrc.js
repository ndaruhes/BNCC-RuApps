module.exports = {
    extends: ["plugin:vue/vue3-essential", "prettier"],
    rules: {
        "vue/no-unused-vars": "error",
        'vue/multi-word-component-names': 0
    }
}