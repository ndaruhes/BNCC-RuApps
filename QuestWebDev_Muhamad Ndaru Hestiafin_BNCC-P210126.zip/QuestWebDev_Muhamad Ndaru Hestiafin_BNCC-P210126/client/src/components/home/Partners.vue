<template>
    <div class="partners" id="partners">
        <div class="container">
            <div class="row">
                <!-- PARTNERS SECTION -->
                <div class="col-md-6" data-aos="fade-down">
                    <div class="section-title">
                        <h1>Rekan Kerja Sama ✨</h1>
                        <div class="line"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 partner">
                            <a href="#" class="col-md-12 partner-content">
                                <img src="@/assets/images/digit.png" alt="Digital Interaktif">
                                <span class="title">Digital Interaktif</span>
                                <span class="desc">Agen pembuatan aplikasi yang tersaji secara interaktif</span>
                            </a>
                        </div>
                        <div class="col-md-6 partner">
                            <a href="#" class="col-md-12 partner-content">
                                <img src="@/assets/images/binus.png" alt="Digital Interaktif">
                                <span class="title">Bina Nusantara</span>
                                <span class="desc">Salah satu universitas swasta terbaik di Indonesia</span>
                            </a>
                        </div>
                        <div class="col-md-6 partner">
                            <a href="#" class="col-md-12 partner-content">
                                <img src="@/assets/images/bncc.png" alt="Digital Interaktif">
                                <span class="title">Binus Computer Club</span>
                                <span class="desc">Sebuah organisasi berbasis IT di Binus University</span>
                            </a>
                        </div>
                        <div class="col-md-6 partner">
                            <a href="#" class="col-md-12 partner-content">
                                <img src="@/assets/images/pojoklaku.png" alt="Digital Interaktif">
                                <span class="title">Pojoklaku</span>
                                <span class="desc">Yayasan yang mendukung pemberdayaan masyarakat</span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- EVENT SECTION -->
                <div class="col-md-6 event" data-aos="fade-up">
                    <div class="section-title">
                        <h1>Event Terbesar Kami 🎉</h1>
                        <div class="line"></div>
                    </div>
                    <span class="event-text">Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy</span>
                    <iframe class="w-100 rounded event-iframe" src="https://www.youtube.com/embed/EjspPVMznkE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</template>