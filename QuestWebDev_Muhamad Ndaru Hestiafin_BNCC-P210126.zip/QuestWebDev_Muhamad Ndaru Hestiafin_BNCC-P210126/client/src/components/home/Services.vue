<template>
    <div class="services" id="services" data-aos="fade-up">
        <div class="container">
            <div class="section-title">
                <h1>Pelayanan Untuk Anda</h1>
                <div class="line"></div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-4 service">
                    <div class="col-md-12 service-content" id="service-content1">
                        <span class="icon"><i class="uil uil-desktop-alt"></i></span>
                        <span class="title">Build Apps</span>
                        <span class="desc">Kami dapat membuat aplikasi sesuai yang anda inginkan</span>
                    </div>
                </div>
                <div class="col-md-4 service">
                    <div class="col-md-12 service-content" id="service-content2">
                        <span class="icon"><i class="uil uil-globe"></i></span>
                        <span class="title">Search Engine Optimization</span>
                        <span class="desc">Website anda akan nomor satu di pencarian situs</span>
                    </div>
                </div>
                <div class="col-md-4 service">
                    <div class="col-md-12 service-content" id="service-content3">
                        <span class="icon"><i class="uil uil-rocket"></i></span>
                        <span class="title">Product Branding</span>
                        <span class="desc">Membuat identitas produk menjadi menarik bersama kami</span>
                    </div>
                </div>
                <div class="col-md-4 service">
                    <div class="col-md-12 service-content" id="service-content5">
                        <span class="icon"><i class="uil uil-server"></i></span>
                        <span class="title">Web Hosting</span>
                        <span class="desc">Kami menyediakan hosting yang cocok untuk kebutuhan anda</span>
                    </div>
                </div>
                <div class="col-md-4 service">
                    <div class="col-md-12 service-content" id="service-content4">
                        <span class="icon"><i class="uil uil-book-reader"></i></span>
                        <span class="title">Online Course</span>
                        <span class="desc">Pembelajaran daring mengenai tips dan trik dalam membangun bisnis</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<style lang="scss" scoped>
// #service-content1 {
//     background: linear-gradient(180deg, #f44881, #ec454f);
// }

// #service-content2 {
//     background: linear-gradient(180deg, #21c8f6, #637bff);
// }

// #service-content3 {
//     background: linear-gradient(0deg, #f19a1a, #ffc73c);
// }

// #service-content4 {
//     background: linear-gradient(0deg, #8b60ed, #b372bd);
// }

// #service-content5 {
//     background: linear-gradient(180deg, #6edcc4, #1aab8b);
// }
</style>