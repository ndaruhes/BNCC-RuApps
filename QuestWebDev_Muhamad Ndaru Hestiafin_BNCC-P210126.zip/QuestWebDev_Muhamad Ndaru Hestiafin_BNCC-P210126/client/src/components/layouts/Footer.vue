<template>
    <div data-aos="fade-up">
        <!-- WAVE -->
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="#F8F9FA" fill-opacity="1" d="M0,288L48,272C96,256,192,224,288,197.3C384,171,480,149,576,165.3C672,181,768,235,864,250.7C960,267,1056,245,1152,250.7C1248,256,1344,288,1392,304L1440,320L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
        </svg>

        <!-- FOOTER -->
        <div class="footer bg-light">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="col-md-12 footer-content">
                            <span class="logo"><i class="uil uil-robot me-2"></i>RuApps.</span>
                            <span class="desc">Lorem ipsum dolor sit amet consectetur, adipisicing elit quo aspernatur molestiae sunt autem, at illum suscipit.</span>
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="col-md-12 footer-content">
                            <div class="title">
                                <span>Top Link<i class="uil uil-link ms-1"></i></span>
                                <div class="line"></div>
                            </div>
                            <ul>
                                <li><a :href="$route == '/' ? '#services' : '/#services'">Layanan</a></li>
                                <li><a :href="$route == '/' ? '#partners' : '/#partners'">Rekan Kerja Sama</a></li>
                                <li><a :href="$route == '/' ? '#testimoni' : '/#testimoni'">Testimoni</a></li>
                                <li><router-link to="/login">Login</router-link></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="col-md-12 footer-content">
                            <div class="title">
                                <span>Hubungi Kami<i class="uil uil-phone-alt ms-1"></i></span>
                                <div class="line"></div>
                            </div>
                            <ul>
                                <li><a href="#"><b>Fax:</b> (021) 5345830</a></li>
                                <li><a href="#"><b>Telepon:</b> +62 838 4823 4436</a></li>
                                <li><a href="#"><b>Alamat:</b> Jl. Raya Kb. Jeruk No.27, Kebon Jeruk, Jakarta Barat</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-3 footer-map">
                        <div class="col-md-12 footer-content">
                            <div class="title">
                                <span>Google Maps<i class="uil uil-map-pin-alt ms-1"></i></span>
                                <div class="line"></div>
                            </div>
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15865.868453949512!2d106.7809316030905!3d-6.201943129977228!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f6dcc7d2c4ad%3A0x209cb1eef39be168!2sUniversitas%20Bina%20Nusantara%2C%20Kampus%20Anggrek!5e0!3m2!1sid!2sid!4v1640068100190!5m2!1sid!2sid" height="150" class="border-none w-100" loading="lazy"></iframe>
                        </div>
                    </div>
                </div>

                <span class="footer-text">&copy; 2021 <a href="#" class="fw-bold text-decoration-none">RuApps</a> | All Right Reserved</span>
            </div>
        </div>
    </div>
</template>

<style lang="scss" scoped>
@import '@/assets/sass/footer.scss';
</style>