export default {
    apiURL: 'http://localhost:3000/'
    // apiURL: 'https://ruapps-api.ndaruhes.com/'
}